
/*
 * GET home page.
 */

exports.joystick = function(req, res){
  res.render('joystick', { title: 'joystick', req: req });
};
