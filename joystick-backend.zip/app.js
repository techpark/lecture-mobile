
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes/joystick');
var http = require('http');
var path = require('path');
var guid = require('guid');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'xml');
app.engine('xml', require('artist').render({
    cache: false,
    debug: true
}));
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(express.cookieParser("R+mP2QeS-\"WzN&<mFs]~_V6WMz X[} =<obw<G-"));
app.use(express.session({
	key: "sid",
	secret: "-b6`_$-+z4nbssRcQhxnv,EFeZvp^-_73TL>3o",
	cookie: {
		path: '/',
		httpOnly: true,
		maxAge: 1000 * 60 * 60 * 24 * 30
	}
}));
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.joystick);
app.get('/desktop', routes.joystick);
app.get('/joystick', routes.joystick);
app.get('/:code', routes.joystick);

var server = http.createServer(app);

var tokens = {};
var bindings = {};

var getToken = function(socket){
	if (socket.token){
		return socket.token;
	}

	var min = parseInt(1000,16);
	var max = parseInt('ffff',16);

	do {
		var token = Math.floor( min + ( max - min ) * Math.random() ).toString(16);
	} while( tokens[token] );

	tokens[token] = {
		desktop: socket
	};
	socket.token = token;

	return token;
};

var io = require('socket.io').listen(server);
io.on('connection', function(socket){
	socket.on('get', function (data, fn) {
		if (data == 'token'){
			getToken(socket);
			fn(socket.token);
		}
	});

	socket.on('bind', function(token, fn){
		if (guid.isGuid(token)){
			if (bindings[token]){
				fn({
					status: 'success',
					guid: g
				});
				return;
			} else {
				fn({
					status: 'error'
				});
			}

			return;
		}

		if (!tokens[token]){
			fn({
				status: 'undefined token'
			});

		} else if (tokens[token].joystick){
			fn({
				status: 'unsuccess'
			});

		} else {
			var g =  guid.create().value;
			fn({
				status: 'success',
				guid: g
			});

			tokens[token].joystick = socket;
			bindings[g] = tokens[token];

			bindings[g].desktop.emit('start', {guid: g});
		}
	});

	socket.on('restore', function(guid, fn){
		if (bindings[guid] && bindings[guid].desktop == socket){
			fn({
				status: 'success'
			});
		} else {
			fn({
				status: 'error'
			});
		}
	});

	socket.on('sms', function(data, fn){
		var binding = bindings[data.guid];
		var sock = binding.desktop === socket ? binding.joystick : binding.desktop;

		sock.emit('sms', data, function(data){
			fn(data);
		});

	});
});

server.listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
